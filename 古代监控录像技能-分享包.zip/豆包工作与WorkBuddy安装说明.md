# 安装与调用

本技能包只负责生成文案和提示词，不会自动生成或发布视频。

## WorkBuddy

官方文档说明支持上传本地技能包：进入「专家·技能·连接器」→「技能」→「添加技能」→「上传技能」，选择 `ancient-cctv-prompts.zip`。导入后确认已启用，再在新对话中请求：

> 用古代监控视频技能，为《凿壁偷光》生成精彩片段脚本文案、场景图片提示词和分段视频提示词。

[WorkBuddy技能文档](https://www.codebuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Skills-Market)

## 豆包工作

豆包开放平台技能指南支持将技能作为自定义技能接入并发布至豆包工作。个人用户可在当前客户端「技能」管理区查看是否提供导入本地技能文件入口，选择同一个ZIP包。企业工作区的自建技能可能需要管理员审核或发布。不同版本菜单会变化；如果没有本地导入入口，可粘贴 `免安装完整指令.md`，再输入主题。

[豆包开放平台技能接入指南](https://open.doubao.com/document/doubao-developer-guide/skill-integration-guide)

## 直接调用

> 主题：凿壁偷光。请输出完整精彩片段脚本、场景图片提示词和分段视频提示词，按情节完整度安排时长，保留黑白低清固定监控、持续时间数字和CAM 01。

导入包包含 `SKILL.md` 和 `references/production-guide.md`，两个文件应一同保留。若平台无法导入ZIP，使用 `免安装完整指令.md`。
